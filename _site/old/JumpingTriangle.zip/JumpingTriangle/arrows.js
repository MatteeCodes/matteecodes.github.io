class Arrows {
  constructor() {
    this.x = 1000
  }
}
