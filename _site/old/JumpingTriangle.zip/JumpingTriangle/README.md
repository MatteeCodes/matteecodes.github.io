# JumpingDorito
 This is a project of a Jumping Dorito in p5JS with the help of the Coding Train (Go sub to him) i watched his videos and it helped alot
